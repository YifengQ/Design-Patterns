public abstract class decoration extends Tree{

    Tree tree;
    public abstract String getName();
}
