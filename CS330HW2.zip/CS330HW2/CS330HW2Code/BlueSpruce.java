public class BlueSpruce extends Tree {

    public String getName(){
        return "Colorado Blue Spruce tree decorated with";
    }

    public int Cost(){
        return 20;
    }
}
