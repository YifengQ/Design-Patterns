public class BalsamFir extends Tree {

    public String getName(){
        return "Balsam Fir tree decorated with";
    }

    public int Cost(){
        return 5;
    }
}
