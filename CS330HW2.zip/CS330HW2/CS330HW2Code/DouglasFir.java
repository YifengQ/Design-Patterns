public class DouglasFir extends Tree {

    public String getName(){
        return "Douglas Fir tree decorated with";
    }

    public int Cost(){
        return 15;
    }
}
