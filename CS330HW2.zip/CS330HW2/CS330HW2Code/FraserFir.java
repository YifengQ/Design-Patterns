public class FraserFir extends Tree {

    public String getName(){
        return "Fraser Fir tree decorated with";
    }

    public int Cost(){
        return 12;
    }
}

